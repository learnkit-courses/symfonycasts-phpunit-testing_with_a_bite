<?php

namespace AppBundle\Exception;

class DinosaursAreRunningRampantException extends \Exception
{
}
